import React from 'react';

// Placeholder component
const SyncHistoryView = () => (
  <div className="p-4">
    <h1 className="text-2xl font-semibold mb-6">Synchronization History</h1>
    <p className="text-gray-500">This is a placeholder for the synchronization history view.</p>
  </div>
);

// Define routes for the sync feature
export const syncRoutes = [
  {
    path: '/sync',
    element: <SyncHistoryView />,
  }
];

import React from 'react';

// Placeholder component
const HierarchyView = () => (
  <div className="p-4">
    <h1 className="text-2xl font-semibold mb-6">Product Hierarchy</h1>
    <p className="text-gray-500">This is a placeholder for the product hierarchy view.</p>
  </div>
);

// Define routes for the hierarchy feature
export const hierarchyRoutes = [
  {
    path: '/hierarchy',
    element: <HierarchyView />,
  }
];

import React, { useState } from 'react';
import { Button } from '../../../components/ui/shadcn/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '../../../components/ui/shadcn/card';
import { Dialog, DialogTrigger, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '../../../components/ui/shadcn/dialog';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '../../../components/ui/shadcn/tabs';

// Mock data types
interface Feature {
  id: string;
  name: string;
  description: string;
  status: 'planned' | 'in-progress' | 'completed' | 'backlog';
  priority: 'low' | 'medium' | 'high' | 'critical';
  parent?: string;
  adoId?: string;
  lastSyncedAt?: string;
}

// Mock data
const MOCK_FEATURES: Feature[] = [
  {
    id: 'f1',
    name: 'User Authentication',
    description: 'Implement secure user authentication with role-based access control',
    status: 'completed',
    priority: 'high',
    adoId: 'ADO-123',
    lastSyncedAt: '2025-04-10T15:30:00Z'
  },
  {
    id: 'f2',
    name: 'Feature Sync Engine',
    description: 'Build a robust synchronization engine that handles bi-directional updates',
    status: 'in-progress',
    priority: 'critical',
    adoId: 'ADO-124',
    lastSyncedAt: '2025-04-11T09:15:00Z'
  },
  {
    id: 'f3',
    name: 'Interactive Dashboard',
    description: 'Create an interactive dashboard with filters and visualizations',
    status: 'planned',
    priority: 'medium',
    adoId: 'ADO-125'
  },
  {
    id: 'f4',
    name: 'Custom Fields Mapping',
    description: 'Add support for mapping custom fields between ProductBoard and Azure DevOps',
    status: 'backlog',
    priority: 'low'
  },
  {
    id: 'f5',
    name: 'Bulk Actions',
    description: 'Implement ability to perform actions on multiple items',
    status: 'backlog',
    priority: 'medium'
  }
];

/**
 * FeatureExplorer component displaying ProductBoard features with filtering and details
 */
export const FeatureExplorer: React.FC = () => {
  // Active tab state
  const [activeTab, setActiveTab] = useState<string>('all');
  
  // Selected feature for details
  const [selectedFeature, setSelectedFeature] = useState<Feature | null>(null);
  
  // Filter features based on active tab
  const getFilteredFeatures = () => {
    if (activeTab === 'all') return MOCK_FEATURES;
    if (activeTab === 'synced') return MOCK_FEATURES.filter(f => f.adoId);
    if (activeTab === 'unsynced') return MOCK_FEATURES.filter(f => !f.adoId);
    
    // Filter by status
    return MOCK_FEATURES.filter(f => f.status === activeTab);
  };
  
  // Get status badge color
  const getStatusColor = (status: Feature['status']) => {
    switch (status) {
      case 'planned': return 'bg-blue-100 text-blue-800';
      case 'in-progress': return 'bg-yellow-100 text-yellow-800';
      case 'completed': return 'bg-green-100 text-green-800';
      case 'backlog': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };
  
  // Get priority badge color
  const getPriorityColor = (priority: Feature['priority']) => {
    switch (priority) {
      case 'low': return 'bg-gray-100 text-gray-800';
      case 'medium': return 'bg-blue-100 text-blue-800';
      case 'high': return 'bg-orange-100 text-orange-800';
      case 'critical': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-semibold">ProductBoard Features</h1>
        <Button variant="primary">Sync Features</Button>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid grid-cols-7 w-full">
          <TabsTrigger value="all">All</TabsTrigger>
          <TabsTrigger value="planned">Planned</TabsTrigger>
          <TabsTrigger value="in-progress">In Progress</TabsTrigger>
          <TabsTrigger value="completed">Completed</TabsTrigger>
          <TabsTrigger value="backlog">Backlog</TabsTrigger>
          <TabsTrigger value="synced">Synced</TabsTrigger>
          <TabsTrigger value="unsynced">Unsynced</TabsTrigger>
        </TabsList>
        
        <TabsContent value={activeTab} className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {getFilteredFeatures().map(feature => (
              <Dialog key={feature.id}>
                <DialogTrigger asChild>
                  <Card 
                    className="cursor-pointer hover:shadow-md transition-shadow duration-200"
                    onClick={() => setSelectedFeature(feature)}
                  >
                    <CardHeader>
                      <div className="flex justify-between">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(feature.status)}`}>
                          {feature.status.replace('-', ' ')}
                        </span>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${getPriorityColor(feature.priority)}`}>
                          {feature.priority}
                        </span>
                      </div>
                      <CardTitle className="mt-2">{feature.name}</CardTitle>
                      <CardDescription className="line-clamp-2">
                        {feature.description}
                      </CardDescription>
                    </CardHeader>
                    <CardFooter className="flex justify-between text-sm text-gray-500">
                      <div>
                        {feature.adoId ? (
                          <span className="flex items-center">
                            <svg className="w-4 h-4 mr-1" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M21 7L12 3L3 7V17L12 21L21 17V7Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                            </svg>
                            {feature.adoId}
                          </span>
                        ) : (
                          <span className="text-red-500">Not synced</span>
                        )}
                      </div>
                      <div>
                        {feature.lastSyncedAt && (
                          <span className="flex items-center">
                            <svg className="w-4 h-4 mr-1" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M12 8V12L15 15M21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                            </svg>
                            {new Date(feature.lastSyncedAt).toLocaleDateString()}
                          </span>
                        )}
                      </div>
                    </CardFooter>
                  </Card>
                </DialogTrigger>
                
                <DialogContent className="sm:max-w-md">
                  <DialogHeader>
                    <DialogTitle>{feature.name}</DialogTitle>
                    <DialogDescription>
                      Feature details from ProductBoard
                    </DialogDescription>
                  </DialogHeader>
                  
                  <div className="space-y-4 py-4">
                    <div className="flex gap-4">
                      <div className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(feature.status)}`}>
                        {feature.status.replace('-', ' ')}
                      </div>
                      <div className={`px-2 py-1 rounded-full text-xs font-medium ${getPriorityColor(feature.priority)}`}>
                        {feature.priority}
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <h4 className="font-medium text-sm">Description</h4>
                      <p className="text-sm text-slate-500">
                        {feature.description}
                      </p>
                    </div>
                    
                    {feature.adoId && (
                      <div className="space-y-2">
                        <h4 className="font-medium text-sm">Azure DevOps ID</h4>
                        <p className="text-sm font-mono bg-slate-100 p-2 rounded">
                          {feature.adoId}
                        </p>
                      </div>
                    )}
                    
                    {feature.lastSyncedAt && (
                      <div className="space-y-2">
                        <h4 className="font-medium text-sm">Last Synced</h4>
                        <p className="text-sm text-slate-500">
                          {new Date(feature.lastSyncedAt).toLocaleString()}
                        </p>
                      </div>
                    )}
                  </div>
                  
                  <DialogFooter className="flex items-center space-x-2">
                    {!feature.adoId ? (
                      <Button variant="primary">Sync to Azure DevOps</Button>
                    ) : (
                      <Button variant="default">Force Resync</Button>
                    )}
                    <Button variant="outline">View in ProductBoard</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            ))}
          </div>
          
          {getFilteredFeatures().length === 0 && (
            <div className="flex flex-col items-center justify-center h-64 bg-gray-50 rounded-lg border border-dashed border-gray-300">
              <svg className="w-12 h-12 text-gray-400 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 5a1 1 0 011-1h14a1 1 0 011 1v14a1 1 0 01-1 1H5a1 1 0 01-1-1V5z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M16 8.99H8M16 13.01H8M10 17.01H8" />
              </svg>
              <h3 className="text-lg font-medium text-gray-900">No features found</h3>
              <p className="text-sm text-gray-500 mt-1">
                No features match the current filter criteria.
              </p>
              <Button variant="outline" className="mt-4" onClick={() => setActiveTab('all')}>
                Show all features
              </Button>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

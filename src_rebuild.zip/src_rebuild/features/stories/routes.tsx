import React from 'react';

// Placeholder component
const StoriesView = () => (
  <div className="p-4">
    <h1 className="text-2xl font-semibold mb-6">Story Management</h1>
    <p className="text-gray-500">This is a placeholder for the Azure DevOps stories view.</p>
  </div>
);

// Define routes for the stories feature
export const storiesRoutes = [
  {
    path: '/stories',
    element: <StoriesView />,
  }
];

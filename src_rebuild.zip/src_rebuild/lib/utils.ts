import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

/**
 * Combines multiple class names using clsx and tailwind-merge
 * This utility is useful for merging Tailwind CSS classes in components
 * 
 * @example
 * ```tsx
 * <div className={cn("text-red-500", isActive && "font-bold", className)}>
 *   Content
 * </div>
 * ```
 */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

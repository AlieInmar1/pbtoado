import React from 'react';
import { twMerge } from 'tailwind-merge';

/**
 * Badge variant styles
 */
export type BadgeVariant = 'default' | 'primary' | 'secondary' | 'success' | 'warning' | 'error' | 'info';

/**
 * Badge sizes
 */
export type BadgeSize = 'sm' | 'md' | 'lg';

/**
 * Props for the Badge component
 */
export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** The variant style of the badge */
  variant?: BadgeVariant;
  
  /** The size of the badge */
  size?: BadgeSize;
  
  /** Whether to use a subtle/outline style */
  subtle?: boolean;
  
  /** Whether to add a dot indicator */
  dot?: boolean;
  
  /** Badge content */
  children?: React.ReactNode;
  
  /** Additional CSS classes */
  className?: string;
}

/**
 * Badge component for displaying status indicators, counts, or tags.
 * 
 * @example
 * ```tsx
 * <Badge variant="success">Completed</Badge>
 * <Badge variant="warning" subtle>Pending</Badge>
 * <Badge variant="primary" dot>New</Badge>
 * <Badge variant="error">3</Badge>
 * ```
 */
export const Badge: React.FC<BadgeProps> = ({
  variant = 'default',
  size = 'md',
  subtle = false,
  dot = false,
  children,
  className,
  ...props
}) => {
  // Variant color styles
  const variantStyles = {
    default: subtle 
      ? 'bg-gray-100 text-gray-800 border border-gray-200' 
      : 'bg-gray-500 text-white',
    primary: subtle 
      ? 'bg-primary-50 text-primary-800 border border-primary-200' 
      : 'bg-primary-500 text-white',
    secondary: subtle 
      ? 'bg-secondary-100 text-secondary-800 border border-secondary-200' 
      : 'bg-secondary-500 text-white',
    success: subtle 
      ? 'bg-green-100 text-green-800 border border-green-200' 
      : 'bg-green-500 text-white',
    warning: subtle 
      ? 'bg-yellow-100 text-yellow-800 border border-yellow-200' 
      : 'bg-yellow-500 text-white',
    error: subtle 
      ? 'bg-red-100 text-red-800 border border-red-200' 
      : 'bg-red-500 text-white',
    info: subtle 
      ? 'bg-blue-100 text-blue-800 border border-blue-200' 
      : 'bg-blue-500 text-white',
  };

  // Size styles
  const sizeStyles = {
    sm: 'text-xs px-1.5 py-0.5',
    md: 'text-xs px-2.5 py-0.5',
    lg: 'text-sm px-3 py-1',
  };

  // Dot styles
  const dotColorStyles = {
    default: 'bg-gray-500',
    primary: 'bg-primary-500',
    secondary: 'bg-secondary-500',
    success: 'bg-green-500',
    warning: 'bg-yellow-500',
    error: 'bg-red-500',
    info: 'bg-blue-500',
  };

  // Combine classes
  const badgeClasses = twMerge(
    'inline-flex items-center font-medium rounded-full',
    variantStyles[variant],
    sizeStyles[size],
    className
  );

  return (
    <span className={badgeClasses} {...props}>
      {dot && (
        <span 
          className={twMerge(
            'w-1.5 h-1.5 rounded-full mr-1.5',
            dotColorStyles[variant]
          )}
          aria-hidden="true"
        />
      )}
      {children}
    </span>
  );
};
